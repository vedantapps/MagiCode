//
//  MainOSView.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

struct MainOSView: View {
    
    @State private var bootLogoOpacity: Double = 0
    @State private var showingMainOS = false
    @State private var restartApp = false
    @State private var showingPortraitAlert = false
    let restartAppNotif = NotificationCenter.default.publisher(for: NSNotification.Name("restartApp"))
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black
                    .edgesIgnoringSafeArea(.all)
                Image(systemName: "apple.logo")
                    .font(.system(size: 100))
                    .opacity(bootLogoOpacity)
                    .onAppear {
                        withAnimation(.linear(duration: 3.5)) {
                            bootLogoOpacity = 1
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.8) {
                            bootLogoOpacity = 0
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                            withAnimation(.easeIn(duration: 1.0))  {
                                showingMainOS = true
                            }
                        }
                    }
                
                if showingMainOS {
                    HomeView()
                        .onReceive(restartAppNotif) {_ in
                            restartApp.toggle()
                        }
                        .navigationDestination(isPresented: $restartApp) {
                            ContentView()
                                .navigationTitle("")
                                .navigationBarBackButtonHidden(true)
                                .navigationBarHidden(true)
                        }
                        .overlay {
                            if showingPortraitAlert {
                                VStack {
                                    Image(systemName: "rectangle.landscape.rotate")
                                        .font(.system(size: 80))
                                        .padding()
                                    Text("Rotate Device to Landscape")
                                        .font(.title)
                                }
                                .bold()
                                .frame(width: 300, height: 300, alignment: .center)
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                                .shadow(radius: 15)
                            }
                        }
                        .onAppear {
                            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                            withAnimation {
                                self.showingPortraitAlert = scene.interfaceOrientation.isPortrait
                            }
                        }
                        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
                            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                            withAnimation {
                                self.showingPortraitAlert = scene.interfaceOrientation.isPortrait
                            }
                        }
                }
            }
            .navigationTitle("")
            .navigationBarBackButtonHidden(true)
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    MainOSView()
}

//
//  MessageApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class MessageState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct MessageApp: View {
    
    @State private var isHovering = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @Binding var hasCompletedStory: Bool
    @Binding var hasCompletedStory2: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var message2 = false
    @State private var message2Overlay = false
    @State private var message4 = false
    @State private var message5 = false
    
    var body: some View {
        VStack {
            HStack(spacing: 0) {
                
                VStack {
                    Text("Messages")
                        .frame(width: 225, alignment: .leading)
                        .padding(.leading, 25)
                        .padding(.vertical, 20)
                        .font(.largeTitle)
                        .bold()
                        
                    ZStack {
                        Color.white
                            .opacity(0.2)
                            .frame(width: 140, height: 140)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        VStack {
                            ZStack {
                                Color(red: 0.76, green: 0.75, blue: 0.99)
                                    .clipShape(Circle())
                                Text("🍎")
                                    .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                                    .font(.system(size: 50, weight: .bold))
                            }
                            .frame(maxWidth: 85, maxHeight: 85)
                            Text("Apple GC")
                        }
                    }
                    Spacer()
                }
                .frame(width: 250, height: 500)
                .background(Color.black.opacity(0.3))
                
                VStack {
                    ZStack {
                        Color(red: 0.76, green: 0.75, blue: 0.99)
                            .clipShape(Circle())
                        Text("🍎")
                            .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                            .font(.system(size: 30, weight: .bold))
                    }
                    .frame(maxWidth: 55, maxHeight: 55)
                    .padding()
                    
                    VStack(alignment: .leading) {
                        SingleMessageView(contactName: "Craig Federighi", contactImage: "C", messageContents: "Hey \(personName), we need your help again!")
                        
                        if message2 {
                            SingleMessageView(contactName: "Tim Cook", contactImage: "T", messageContents: "We need to update our devices! Open CodeEdit to compile the new update before WWDC 2024.")
                                .frame(maxWidth: 500, alignment: .leading)
                            
                            if !hasCompletedStory {
                                ZStack(alignment: .leading) {
                                    Rectangle()
                                        .background(.white.opacity(0.05))
                                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                                        .frame(width: 350, height: 100)
                                        .padding(.leading, 38)
                                    
                                    HStack {
                                        ZStack {
                                            Circle()
                                                .fill(Color(red: 0.30, green: 0.62, blue: 0.90))
                                            
                                            Image("CodeLayer")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 35, height: 35)
                                                .shadow(radius: 4)
                                            
                                        }
                                        .frame(width: 60, height: 60)
                                        
                                        Text("Open CodeEdit")
                                            .bold()
                                        
                                        Button {
                                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "opencode"), object: self, userInfo: nil)
                                        } label: {
                                            ZStack {
                                                Capsule()
                                                    .frame(width: 80, height: 40)
                                                    .foregroundColor(.primary)
                                                Text("Launch")
                                                    .bold()
                                                    .foregroundColor(.white)
                                            }
                                            .padding(.leading, 45)
                                        }
                                    }
                                    .padding(.leading, 50)
                                }
                                .onTapGesture {
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "opencode"), object: self, userInfo: nil)
                                }
                                .hoverOverlay(overlayPoints: overlayPoints, isHovering: $message2Overlay, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "opencode"), object: self, userInfo: nil)
                                })
                            }
                        }
                        
                        if hasCompletedStory {
                            HStack {
                                Spacer()
                                Text("Update has been compiled!")
                                    .font(.system(size: 17, weight: .regular))
                                    .padding(10)
                                    .background(Color(red: 0.04, green: 0.46, blue: 1.00))
                                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                            }
                        }
                        
                        if message4 {
                            SingleMessageView(contactName: "Tim Cook", contactImage: "T", messageContents: "Thanks again \(personName)!")
                        }
                        
                        if message5 {
                            SingleMessageView(contactName: "Craig Federighi", contactImage: "C", messageContents: "Feel free to close Messages and explore around! Open App Info to see a list of what every app can do.")
                                .frame(maxWidth: 500, alignment: .leading)
                        }
                        
                    }
                    .padding(.horizontal, 15)
                    .frame(width: 550, alignment: .leading)
                    
                    Spacer()
                }
                .frame(width: 550, height: 500)
            }
            .frame(width: 800, height: 500)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
         
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
            
        }
        .onAppear {
            if !hasCompletedStory {
                withAnimation(.default.delay(2.0)) {
                    message2 = true
                }
            } else {
                message2 = true
            }
            
            if !hasCompletedStory2 && hasCompletedStory {
                hasCompletedStory2 = true
                withAnimation(.default.delay(1.5)) {
                    message4 = true
                }
                withAnimation(.default.delay(3.0)) {
                    message5 = true
                }
            } else if hasCompletedStory && hasCompletedStory2 {
                message4 = true
                message5 = true
            }
        }
    }
}

#Preview {
    MessageApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false), hasCompletedStory: .constant(true), hasCompletedStory2: .constant(true))
}


struct SingleMessageView: View {

    var contactName: String
    var contactImage: String
    var messageContents: String
    
    var body: some View {
        HStack {
            ZStack {
                Circle()
                    .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                    .frame(width: 30, height: 30)
                Text(contactImage)
                    .foregroundColor(.white)
                    .font(.system(size: 15, weight: .bold))
            }
            .offset(y: 6)
            VStack(alignment: .leading, spacing: 0) {
                if contactName != "" {
                    Text(contactName)
                        .foregroundColor(.white)
                        .font(.system(size: 11, weight: .medium))
                        .padding(.bottom, 3)
                }
                
                Text(messageContents)
                    .font(.system(size: 17, weight: .regular))
                    .padding(10)
                    .background(.white.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
            .padding(.leading, 2)
        }
    }
}

//
//  CodeEditApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class CodeEditState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct CodeEditApp: View {
    var todayDate: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yy"
        return formatter.string(from: Date())
    }
    
    @State private var isHovering = false
    @State private var playHover = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @Binding var hasCompletedStory: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var rightInfoText = ""
    @State private var playPressed = false
    var body: some View {
        VStack {
            ZStack {
                Rectangle()
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 48, style: .continuous))
                    .shadow(radius: 10)
                
                HStack {
                    Button {
                        withAnimation {
                            playPressed = true
                            rightInfoText = "Building | 1/1024"
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            withAnimation {
                                rightInfoText = "Building | 512/1024"
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation {
                                rightInfoText = "Compiled LatestUpdate on Device"
                            }
                        }
                    } label: {
                        Image(systemName: "play.fill")
                            .font(.title)
                            .foregroundColor(playPressed ? .green : .white)
                            .padding(14)
                            .background(.white.opacity(playHover ? 0.6 : 0.2))
                    }
                    .clipShape(Circle())
                    .padding(.horizontal, 8)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $playHover, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                        withAnimation {
                            playPressed = true
                            rightInfoText = "Building | 1/1024"
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            withAnimation {
                                rightInfoText = "Building | 512/1024"
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation {
                                rightInfoText = "Compiled LatestUpdate on Device"
                            }
                        }
                    })
                    
                    Spacer()
                    
                    Text(rightInfoText)
                        .bold()
                        .padding(.trailing, 5)
                        .onChange(of: rightInfoText) {_ in
                            if rightInfoText == "Compiled LatestUpdate on Device" {
                                if hasCompletedStory == false {
                                    hasCompletedStory = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "codedone"), object: self, userInfo: nil)
                                    }
                                }
                            }
                        }
                    
                    if rightInfoText == "Compiled LatestUpdate on Device" {
                        Image(systemName: "checkmark.circle")
                            .foregroundColor(.green)
                            .font(.largeTitle)
                            .bold()
                            .padding(.trailing)
                        

                    }
                }
            }
            .padding()
            .frame(height: 100)
            
            ZStack(alignment: .leading) {
                
                let codeString = """
                //
                // LatestUpdate.swift
                // MagiCode
                //
                // Created by \(personName) on \(todayDate)
                //
                
                let currentVersion = Device.currentVersion()
                let update = NewVersion()
                update.version = 18.0
                
                if currentVersion < 18.0 {
                    Device.updateToVersion(update)
                }
                """
                
                Rectangle()
                    .background(.ultraThinMaterial)
                VStack(alignment: .leading) {
                    Text(codeString)
                        .font(.system(size: 20, design: .monospaced))
                        .padding()
                    
                    if !hasCompletedStory {
                        Text("Run this code via the play button in the top left to finish the story.")
                            .font(.system(size: 20, design: .monospaced))
                            .padding()
                            .bold()
                            .padding(.top)
                    }
                    Spacer()
                }
            }
            .frame(maxHeight: 500)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
            
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
                
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
        }
    }
}

#Preview {
    CodeEditApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false), hasCompletedStory: .constant(false))
}

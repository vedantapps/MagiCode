var personName = "WWDC attendee"

import SwiftUI
import AVFoundation

struct ContentView: View {    
    // The starting view of the app

    // Background colors
    let bgColorSet = [Color(red: 0.99, green: 0.33, blue: 0.00), Color(red: 0.62, green: 0.23, blue: 0.64), Color(red: 0.14, green: 0.15, blue: 0.78), Color(red: 0.00, green: 0.59, blue: 0.99), Color(red: 0.00, green: 0.56, blue: 0.36)]
    @State private var bgAnimate = false
    
    // Button Animation
    @State private var buttonMax = false
    @State private var initialName = ""
    @FocusState private var textFieldFocus: Bool
    @State private var cameraGranted = false
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: bgColorSet), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
                .onAppear {
                    DispatchQueue.main.async {
                        withAnimation(.linear(duration: 8.0).repeatForever(autoreverses: true)) {
                            bgAnimate.toggle()
                        }
                    }
                }
                .blur(radius: 50)
                .scaleEffect(1.3)
                .opacity(0.8)
            
            VStack {
                VStack {
                    // Title & Subtitle Text
                    Group {
                        Image(systemName: "hands.and.sparkles.fill")
                            .font(.system(size: 40, weight: .heavy, design: .rounded))
                        
                        Text("MagiCode")
                            .font(.system(size: 50, weight: .semibold, design: .rounded))
                            .padding(.bottom)
                        
                        Text("Magic is in the air.")
                            .multilineTextAlignment(.center)
                            .font(.system(size: 25, weight: .semibold, design: .rounded))
                            .padding(.bottom)
                    }
                    .blur(radius: textFieldFocus ? 20 : 0)
                    // Name Text Field
                    ZStack {
                        Color.white.opacity(0.75)
                        HStack {
                            ZStack(alignment: .leading) {
                                if initialName.isEmpty {
                                    Text("Enter your name (Optional)")
                                        .foregroundColor(.gray)
                                        .padding()
                                }
                                TextField("", text: $initialName)
                                    .padding()
                                    .focused($textFieldFocus)
                                    .onChange(of: initialName) {_ in
                                        DispatchQueue.main.async {
                                            personName = initialName
                                        }
                                    }
                            }
                            Spacer()
                            Button("Done") {
                                textFieldFocus = false
                            }
                            .padding(.trailing)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .foregroundColor(.black)
                    .frame(maxWidth: 400, maxHeight: 30)
                    .padding()
                }
                .padding()
                .frame(maxWidth: 480)
                .background(.white.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                
                // Camera Access View
                HStack {
                    Group {
                        Image(systemName: "camera")
                            .font(.system(size: 40, weight: .medium, design: .rounded))
                        Text("Camera Access")
                            .font(.system(size: 25, weight: .semibold, design: .rounded))
                        Spacer()
                        Text(cameraGranted ? "Granted" : "Not Granted")
                            .fontWeight(.heavy)
                            .foregroundStyle(cameraGranted ? .green : .red)
                    }
                    .blur(radius: textFieldFocus ? 20 : 0)
                }
                .padding()
                .frame(maxWidth: 480)
                .background(.white.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                
                NavigationLink {
                    PreInfoView(cameraStatus: cameraGranted)
                        .navigationTitle("")
                        .navigationBarBackButtonHidden(true)
                        .navigationBarHidden(true)
                } label: {
                    ZStack {
                        Circle()
                            .strokeBorder(LinearGradient(gradient: Gradient(colors: [Color.red, Color.green, Color.blue]), startPoint: .bottomLeading, endPoint: .topTrailing), lineWidth: 18)
                            .scaleEffect(buttonMax ? 0.85 : 1.0)
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 5).repeatForever(autoreverses: true), {
                                    buttonMax = true
                                })
                            }
                        VStack {
                            Text("Start")
                            Image(systemName: "arrow.right")
                        }
                        .font(.system(size: 50, weight: .semibold, design: .rounded))
                        .foregroundColor(.white)
                    }
                    .ignoresSafeArea(.keyboard)
                    .frame(maxWidth: 260, maxHeight: 260)
                }
                .padding(.top, 40)
            }
        }
        .onAppear {
            AVCaptureDevice.requestAccess(for: .video) { cameraAccessStatus in
                cameraGranted = cameraAccessStatus
            }
        }
    }
}

//
//  CameraPreview.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/10/24.
//

import Foundation
import UIKit
import AVFoundation

final class CameraPreview: UIView {
    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }
    var previewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }
}

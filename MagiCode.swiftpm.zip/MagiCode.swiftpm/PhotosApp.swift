//
//  PhotosApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class PhotosState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct PhotosApp: View {
    @State private var isHovering = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var currentPhoto = ""
    @State private var togglePhotoFull = false
    @State private var backIsHovering = false
    @State private var oneHover = false
    @State private var twoHover = false
    @State private var threeHover = false
    
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                Text("All Photos")
                    .padding(.horizontal, 25)
                    .padding(.vertical, 20)
                    .font(.largeTitle)
                    .bold()
                
                HStack(alignment: .top, spacing: 0) {
                    Image("Photos1")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .scaledToFill()
                        .onTapGesture {
                            currentPhoto = "Photos1"
                            withAnimation {
                                togglePhotoFull = true
                            }
                        }
                        .hoverOverlay(overlayPoints: overlayPoints, isHovering: $oneHover, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                            if currentPhoto == "" {
                                currentPhoto = "Photos1"
                                withAnimation {
                                    togglePhotoFull = true
                                }
                            }
                        })
                        .overlay {
                            Color.white.opacity (oneHover ? 0.08 : 0.0)
                                .frame(width: 200, height: 200)
                        }
                    Image("Photos2")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .scaledToFill()
                        .onTapGesture {
                            currentPhoto = "Photos2"
                            withAnimation {
                                togglePhotoFull = true
                            }
                        }
                        .hoverOverlay(overlayPoints: overlayPoints, isHovering: $twoHover, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                            if currentPhoto == "" {
                                currentPhoto = "Photos2"
                                withAnimation {
                                    togglePhotoFull = true
                                }
                            }
                        })
                        .overlay {
                            Color.white.opacity (twoHover ? 0.08 : 0.0)
                                .frame(width: 200, height: 200)
                        }
                    Image("Photos3")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .scaledToFill()
                        .onTapGesture {
                            currentPhoto = "Photos3"
                            withAnimation {
                                togglePhotoFull = true
                            }
                        }
                        .hoverOverlay(overlayPoints: overlayPoints, isHovering: $threeHover, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                            if currentPhoto == "" {
                                currentPhoto = "Photos3"
                                withAnimation {
                                    togglePhotoFull = true
                                }
                            }
                        })
                        .overlay {
                            Color.white.opacity (threeHover ? 0.08 : 0.0)
                                .frame(width: 200, height: 200)
                        }
                    Spacer()
                }
                .padding(.vertical)
                
                Spacer()
            }
            .frame(width: 800, height: 500)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
            .overlay {
                if togglePhotoFull {
                    ZStack {
                        Image("\(currentPhoto)")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 800, height: 500)
                            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        HStack {
                            VStack(alignment: .leading) {
                                Button {
                                    withAnimation {
                                        currentPhoto = ""
                                        togglePhotoFull = false
                                    }
                                } label: {
                                    Image(systemName: "chevron.left")
                                        .font(.title2)
                                        .padding(20)
                                        .foregroundColor(.white)
                                        .background(.gray.opacity(backIsHovering ? 0.8 : 0.4))
                                }
                                .clipShape(Circle())
                                .shadow(radius: 10)
                                .hoverOverlay(overlayPoints: overlayPoints, isHovering: $backIsHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                                    withAnimation {
                                        currentPhoto = ""
                                        togglePhotoFull = false
                                    }
                                })
                                Spacer()
                            }
                            Spacer()
                        }
                        .padding()
                    }
                }
            }

            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            }) 
        }
    }
}

#Preview {
    PhotosApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false))
}

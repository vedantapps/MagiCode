//
//  HomeView.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

struct HomeView: View {
    
    @State private var overlayPoints: [CGPoint] = []
    @State private var distanceCheck = false
    @State private var toggleApps = false
    @State private var currentApp = ""
    @State private var handTrackingDisabled = false
    let closeApp = NotificationCenter.default.publisher(for: NSNotification.Name("closeApp"))
    let openCode = NotificationCenter.default.publisher(for: NSNotification.Name("opencode"))
    let codeDone = NotificationCenter.default.publisher(for: NSNotification.Name("codedone"))
    
    @StateObject private var countdown = CountdownState()
    @StateObject private var magicdraw = MagicDrawState()
    @StateObject private var messages = MessageState()
    @StateObject private var codeedit = CodeEditState()
    @StateObject private var photos = PhotosState()
    @StateObject private var appinfo = InfoState()
    @StateObject private var settings = SettingsState()
    
    @State private var hasCompletedStory = false
    @State private var hasCompletedStory2 = false
    @State private var messageOverlay = false
    @State private var primaryMessage = false
    @State private var helperMessage = false
    @State private var tappedOnMessage = false
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var minimumPinchDistance = 60.0
    
    var body: some View {
        ZStack {
            if !handTrackingDisabled {
                CameraView {
                    overlayPoints = $0
                }
                .opacity(0.1)
                .onChange(of: overlayPoints) {_ in
                    if overlayPoints.count > 1 {
                        let distance = sqrt(pow(overlayPoints[1].x - overlayPoints[0].x, 2) + pow(overlayPoints[1].y - overlayPoints[0].y, 2))
                        if distance < minimumPinchDistance && distance != 0.0 {
                            distanceCheck = true
                        } else {
                            distanceCheck = false
                        }
                    } else {
                        distanceCheck = false
                    }
                }
            }
            
            Image("ApplePark")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 50) {
                // Row 1
                HStack(spacing: 70) {
                    // Countdown
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "countdown"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(.white)
                                Image("CalenderLayer")
                                    .resizable()
                                    .scaledToFill()
                                    .clipShape(Circle())
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: countdown.isHovering ? -3 : 0)
                            .scaleEffect(countdown.isHovering ? 1.1 : 1.0)
                            .shadow(radius: countdown.isHovering ? 6 : 0)
                            
                            Text("Countdown")
                                .foregroundColor(countdown.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(countdown.isHovering ? 1.05 : 1.0)
                    .offset(y: countdown.isHovering ? -2 : 0)
                    .shadow(radius: countdown.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $countdown.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: countdown.lastExecutionTime, tapAction: {
                        countdown.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "countdown"
                            }
                        }
                    })
                    
                    // MagicDraw
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "magicdraw"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.97, green: 0.82, blue: 0.31))
                                Image("DrawLayer")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: magicdraw.isHovering ? -3 : 0)
                            .scaleEffect(magicdraw.isHovering ? 1.1 : 1.0)
                            .shadow(radius: magicdraw.isHovering ? 6 : 0)
                            
                            Text("MagicDraw")
                                .foregroundColor(magicdraw.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(magicdraw.isHovering ? 1.05 : 1.0)
                    .offset(y: magicdraw.isHovering ? -2 : 0)
                    .shadow(radius: magicdraw.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $magicdraw.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: magicdraw.lastExecutionTime, tapAction: {
                        magicdraw.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "magicdraw"
                            }
                        }
                    })
                }
                
                // Row 2
                HStack(spacing: 70) {
                    // Messages
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "message"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.40, green: 0.80, blue: 0.35))
                                Image("MessageLayer")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: messages.isHovering ? -3 : 0)
                            .scaleEffect(messages.isHovering ? 1.1 : 1.0)
                            .shadow(radius: messages.isHovering ? 6 : 0)
                            
                            Text("Messages")
                                .foregroundColor(messages.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(messages.isHovering ? 1.05 : 1.0)
                    .offset(y: messages.isHovering ? -2 : 0)
                    .shadow(radius: messages.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $messages.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: messages.lastExecutionTime, tapAction: {
                        messages.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "message"
                            }
                        }
                    })
                    
                    // Code Edit
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "codeedit"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.30, green: 0.62, blue: 0.90))
                                Image("CodeLayer")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: codeedit.isHovering ? -3 : 0)
                            .scaleEffect(codeedit.isHovering ? 1.1 : 1.0)
                            .shadow(radius: codeedit.isHovering ? 6 : 0)
                            
                            Text("CodeEdit")
                                .foregroundColor(codeedit.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(codeedit.isHovering ? 1.05 : 1.0)
                    .offset(y: codeedit.isHovering ? -2 : 0)
                    .shadow(radius: codeedit.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $codeedit.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: codeedit.lastExecutionTime, tapAction: {
                        codeedit.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "codeedit"
                            }
                        }
                    })
                    
                    // Photos
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "photos"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(.white)
                                Image("PhotosLayer")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: photos.isHovering ? -3 : 0)
                            .scaleEffect(photos.isHovering ? 1.1 : 1.0)
                            .shadow(radius: photos.isHovering ? 6 : 0)
                            
                            Text("Photos")
                                .foregroundColor(photos.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(photos.isHovering ? 1.05 : 1.0)
                    .offset(y: photos.isHovering ? -2 : 0)
                    .shadow(radius: photos.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $photos.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: photos.lastExecutionTime, tapAction: {
                        photos.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "photos"
                            }
                        }
                    })
                    
                }
                
                // Row 3
                HStack(spacing: 70) {
                    // App Info
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "appinfo"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color(UIColor.lightGray))
                                Image("AppInfoLayer")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: appinfo.isHovering ? -3 : 0)
                            .scaleEffect(appinfo.isHovering ? 1.1 : 1.0)
                            .shadow(radius: appinfo.isHovering ? 6 : 0)
                            
                            Text("App Info")
                                .foregroundColor(appinfo.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(appinfo.isHovering ? 1.05 : 1.0)
                    .offset(y: appinfo.isHovering ? -2 : 0)
                    .shadow(radius: appinfo.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $appinfo.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: appinfo.lastExecutionTime, tapAction: {
                        appinfo.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "appinfo"
                            }
                        }
                    })
                    
                    // Settings
                    Button {
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "settings"
                            }
                        }
                    } label: {
                        VStack {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.22, green: 0.22, blue: 0.22))
                                Image("SettingsLayer")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                            }
                            .frame(width: 150, height: 150)
                            .offset(y: settings.isHovering ? -3 : 0)
                            .scaleEffect(settings.isHovering ? 1.1 : 1.0)
                            .shadow(radius: settings.isHovering ? 6 : 0)
                            
                            Text("Settings")
                                .foregroundColor(settings.isHovering ? .primary : .secondary)
                                .fontWeight(.medium)
                                .padding(.top, 5)
                        }
                    }
                    .scaleEffect(settings.isHovering ? 1.05 : 1.0)
                    .offset(y: settings.isHovering ? -2 : 0)
                    .shadow(radius: settings.isHovering ? 4 : 0)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $settings.isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: settings.lastExecutionTime, tapAction: {
                        settings.lastExecutionTime = DispatchTime.now()
                        if currentApp == "" && tappedOnMessage == true {
                            withAnimation {
                                toggleApps = false
                                currentApp = "settings"
                            }
                        }
                    })
                    
                }
                
            }
            .blur(radius: toggleApps ? 0 : 80)
            .scaleEffect(toggleApps ? 1.0 : 1.2)
            .opacity(toggleApps ? 1 : 0)
            
            if countdown.isShowing {
                CountdownApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck)
                    .frame(maxWidth: 800)
                    .transition(.opacity)
            }
            
            if magicdraw.isShowing {
                MagicDrawApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck)
                    .frame(maxWidth: 800)
            }
            
            if photos.isShowing {
                PhotosApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck)
                    .frame(maxWidth: 800)
            }
            
            if codeedit.isShowing {
                CodeEditApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck, hasCompletedStory: $hasCompletedStory)
                    .frame(maxWidth: 800)
            }
            
            if messages.isShowing {
                MessageApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck, hasCompletedStory: $hasCompletedStory, hasCompletedStory2: $hasCompletedStory2)
                    .frame(maxWidth: 800)
            }
            
            if appinfo.isShowing {
                InfoApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck)
                    .frame(maxWidth: 800)
            }
            
            if settings.isShowing {
                SettingsApp(overlayPoints: $overlayPoints, distanceCheck: $distanceCheck, isHandTrackingDisabled: $handTrackingDisabled, minPinchDistance: $minimumPinchDistance)
            }
        }
        .onChange(of: currentApp) {_ in
            switch currentApp{
            case "countdown":
                withAnimation(.default.delay(0.3)) {
                    countdown.isShowing = true
                }
            case "magicdraw":
                withAnimation(.default.delay(0.3)) {
                    magicdraw.isShowing = true
                }
            case "photos":
                withAnimation(.default.delay(0.3)) {
                    photos.isShowing = true
                }
            case "codeedit":
                withAnimation(.default.delay(0.3)) {
                    codeedit.isShowing = true
                }
            case "message":
                withAnimation(.default.delay(0.3)) {
                    messages.isShowing = true
                }
            case "appinfo":
                withAnimation(.default.delay(0.3)) {
                    appinfo.isShowing = true
                }
            case "settings":
                withAnimation(.default.delay(0.3)) {
                    settings.isShowing = true
                }
            default:
                withAnimation(.default.delay(0.3)) {
                    countdown.isShowing = false
                    magicdraw.isShowing = false
                    photos.isShowing = false
                    codeedit.isShowing = false
                    messages.isShowing = false
                    appinfo.isShowing = false
                    settings.isShowing = false
                }
            }
        }
        .onReceive(closeApp) {_ in
            withAnimation(.default.delay(0.3)) {
                currentApp = ""
                toggleApps = true
            }
        }
        .onReceive(openCode) {_ in
            withAnimation {
                messages.isShowing = false
                currentApp = ""
                currentApp = "codeedit"
            }
        }
        .onReceive(codeDone) {_ in
            withAnimation {
                codeedit.isShowing = false
                toggleApps = false
                currentApp = ""
                currentApp = "message"
            }
        }
        .overlay {
            if !tappedOnMessage {
                VStack {
                    if primaryMessage {
                        ZStack {
                            Rectangle()
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 48, style: .continuous))
                                .frame(width: 600, height: 100)
                                .shadow(radius: 10)
                            
                            HStack {
                                ZStack {
                                    Circle()
                                        .fill(Color(red: 0.40, green: 0.80, blue: 0.35))
                                    Image("MessageLayer")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 55, height: 55)
                                }
                                .frame(width: 85, height: 85)
                                .padding(.horizontal, 8)
                                
                                VStack(alignment: .leading) {
                                    Text("Craig Federighi")
                                        .bold()
                                    Text("Apple GC")
                                        .bold()
                                    Text("Hey \(personName), we need your help again!")
                                }
                                
                                Spacer()
                                
                                ZStack {
                                    Capsule()
                                        .frame(width: 80, height: 40)
                                        .foregroundColor(.secondary)
                                    Text("Open")
                                        .bold()
                                        .foregroundColor(.white)
                                }
                                .padding(.trailing, 25)
                            }
                        }
                        .frame(width: 600)
                    }
                    
                    if helperMessage {
                        ZStack {
                            Rectangle()
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 48, style: .continuous))
                                .frame(width: 450, height: 80)
                                .shadow(radius: 10)
                            
                            Text("Open Craig's message by pinching your index finger and thumb over it, or by tapping on the screen.")
                                .bold()
                                .padding()
                                .multilineTextAlignment(.center)
                        }
                        .frame(width: 300)
                    }
                    Spacer()
                }
                .padding(.top, 180)
                .onTapGesture {
                    withAnimation {
                        toggleApps = false
                        currentApp = "message"
                        tappedOnMessage = true
                    }
                }
                .hoverOverlay(overlayPoints: overlayPoints, isHovering: $messageOverlay, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                    withAnimation {
                        toggleApps = false
                        currentApp = "message"
                        tappedOnMessage = true
                    }
                })
            }
        }
        .overlay {
            VStack {
                Text("Thumb")
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundColor(.green)
            }
            .position(overlayPoints.first ?? CGPoint(x: -20, y: -20))
            
            VStack {
                Text("Index")
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundColor(.green)
            }
            .position(overlayPoints.count > 1 ? overlayPoints[1] : CGPoint(x: -20, y: -20))
        }
        .onAppear {
            withAnimation(.spring(duration: 0.5).delay(1.5)) {
                toggleApps = true
            }
            
            withAnimation(.linear(duration: 0.5).delay(2.5)) {
                primaryMessage = true
            }
            
            withAnimation(.linear(duration: 0.5).delay(4.0)) {
                helperMessage = true
            }
        }
    }
}

#Preview {
    HomeView()
}

extension View {
    func hoverOverlay(overlayPoints: [CGPoint], isHovering: Binding<Bool>, distanceCheck: Bool, timeSinceLastExecution: DispatchTime, tapAction: @escaping () -> Void) -> some View {
        self.overlay {
            GeometryReader { geometry in
                Color.clear
                    .onChange(of: overlayPoints) { _ in
                        if let firstPoint = overlayPoints.first {
                            if overlayPoints.count > 1 {
                                let secondPoint = overlayPoints[1]
                                let buttonRect = geometry.frame(in: .global)
                                
                                if buttonRect.contains(CGPoint(x: firstPoint.x, y: firstPoint.y)) || buttonRect.contains(CGPoint(x: secondPoint.x, y: secondPoint.y)) {
                                    withAnimation {
                                        isHovering.wrappedValue = true
                                    }
                                    if distanceCheck {
                                        let currentTime = DispatchTime.now()
                                        let timeSinceLastExecution = currentTime.uptimeNanoseconds - timeSinceLastExecution.uptimeNanoseconds
                                        if timeSinceLastExecution >= 1 * NSEC_PER_SEC {
                                            tapAction()
                                            isHovering.wrappedValue = false
                                            isHovering.wrappedValue = true
                                        }
                                    }
                                } else {
                                    withAnimation {
                                        isHovering.wrappedValue = false
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }
}

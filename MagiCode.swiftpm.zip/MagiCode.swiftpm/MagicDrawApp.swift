//
//  MagicDrawApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI
import PencilKit

class MagicDrawState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct MagicDrawApp: View {
    
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var isHovering = false
    @State private var canvas = PKCanvasView()
    @State private var canvasTool = PKInkingTool(.pen, width: 4)
    @State private var handDrawings: [ViewCircles] = []
    @State private var deleteIsHovering = false
    
    var body: some View {
        VStack {
            ZStack {
                Rectangle()
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 48, style: .continuous))
                    .shadow(radius: 10)
                
                HStack {
                    Button {
                        canvas.drawing = PKDrawing()
                        handDrawings.removeAll()
                    } label: {
                        Image(systemName: "trash.fill")
                            .font(.largeTitle)
                            .padding(8)
                            .foregroundColor(.red)
                            .background(.white.opacity(deleteIsHovering ? 0.6 : 0.2))
                    }
                    .clipShape(Circle())
                    .padding(.horizontal, 8)
                    .hoverOverlay(overlayPoints: overlayPoints, isHovering: $deleteIsHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                        canvas.drawing = PKDrawing()
                        handDrawings.removeAll()
                    })
                    
                    Spacer()
                    
                    Text("Use your Apple Pencil or pinch your index and thumb together to draw in the canvas.")
                        .padding(.trailing)
                        .frame(maxWidth: 500)
                        .multilineTextAlignment(.center)
                }
            }
            .padding()
            .frame(height: 100)
            
            ZStack {
                Canvas(canvas: canvas, canvasTool: canvasTool)
                ForEach(handDrawings) { drawing in
                    drawing.view
                }
            }
            .frame(maxHeight: 500)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
            
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
        }
        .onChange(of: overlayPoints) {_ in
            if distanceCheck {
                if overlayPoints.count > 1 {
                    handDrawings.append(ViewCircles(id: UUID(), position: CGPoint(x: overlayPoints[1].x - 185, y: overlayPoints[1].y - 165)))
                }
            }
        }
    }
}

#Preview {
    MagicDrawApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false))
}


struct Canvas: UIViewRepresentable {
    var canvas: PKCanvasView
    var canvasTool: PKInkingTool
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvas.tool = canvasTool
        canvas.drawingPolicy = .pencilOnly
        return canvas
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        canvas.drawingPolicy = .pencilOnly
        
        DispatchQueue.main.async {
            self.canvas.becomeFirstResponder()
            uiView.becomeFirstResponder()
            
        }
    }
}

struct ViewCircles: Identifiable {
    var id: UUID
    var position: CGPoint
    var view: some View {
        Circle()
            .frame(width: 8, height: 8)
            .foregroundColor(.white)
            .position(position)
    }
}

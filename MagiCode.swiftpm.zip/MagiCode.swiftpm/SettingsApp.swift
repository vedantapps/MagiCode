//
//  SettingsApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class SettingsState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct SettingsApp: View {
    @State private var isHovering = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @Binding var isHandTrackingDisabled: Bool
    @Binding var minPinchDistance: Double
    @State private var lastExecutionTime: DispatchTime = .now()
    @State private var restartApp = false
    @State private var restartAppNotif = false
    @State private var confidence = Double(trackingConfidence)
    
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                Text("Settings")
                    .padding(.top, 20)
                    .font(.largeTitle)
                    .bold()
                
                List {
                    Section {
                        HStack {
                            Spacer()
                            Image("AppIconSmall")
                                .resizable()
                                .frame(width: 150, height: 150, alignment: .center)
                                .clipShape(RoundedRectangle(cornerRadius: 33.33, style: .continuous))
                                .shadow(radius: 5)
                            Spacer()
                        }
                    }
                    .listRowBackground(Color.clear)
                    .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                    
                    Section {
                        Text("MagiCode | 2024 Swift Student Challenge")
                            .bold()
                        Text("Note: Hand tracking is disabled within Settings.")
                    }
                    
                    Section(header: Text("Hand Tracking Settings"), footer: Text("Adjust the slider to increase/decrease hand tracking confidence. Higher may not always be better.")) {
                        
                        Button(isHandTrackingDisabled ? "Enable Hand Tracking" : "Disable Hand Tracking") {
                            isHandTrackingDisabled.toggle()
                        }
                        .foregroundColor(isHandTrackingDisabled ? .blue : .red)
                        
                        HStack {
                            Text("Tracking Confidence")
                            Slider(value: $confidence, in: 0.1...0.9)
                                .padding(.horizontal)
                            Text("\(confidence)")
                        }
                        .onChange(of: confidence) {_ in
                            trackingConfidence = Float(confidence)
                        }
                    }
                    
                    Section(header: Text("Pinch Selection Settings"), footer: Text("Adjust the slider to increase/decrease pinching distance for selection. Higher distance may result in more accidental selections.")) {
                        
                        HStack {
                            Text("Pinch Distance")
                            Slider(value: $minPinchDistance, in: 30.0...90.0)
                                .padding(.horizontal)
                            Text("\(minPinchDistance)")
                        }
                    }
                    
                    Section {
                        Button("Restore Tracking Defaults") {
                            isHandTrackingDisabled = false
                            confidence = 0.20
                            minPinchDistance = 60.0
                        }
                    }
                    
                    Section {
                        Button("Restart Experience") {
                            restartAppNotif.toggle()
                        }
                        .foregroundColor(.red)
                    }
                    .alert("Restart MagiCode?\n\nAre you sure you would like to restart MagiCode? All current progress will be lost.", isPresented: $restartAppNotif) {
                        Button("Yes", role: .destructive){
                            personName = "WWDC attendee"
                            confidence = 0.20
                            minPinchDistance = 60.0
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "restartApp"), object: self, userInfo: nil)
                        }
                        Button("Cancel", role: .cancel){}
                    }

                    Section {
                        HStack {
                            Spacer()
                            VStack {
                                Image(systemName: "swift")
                                    .font(.title)
                                    .foregroundColor(.secondary)
                                
                                Text("WWDC 2024 Swift Student Challenge")
                                    .foregroundColor(.secondary)
                                    .font(.subheadline)
                                    .padding()
                            }
                            Spacer()
                        }
                    }
                    .listRowBackground(Color.clear)
                    .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                }
                .scrollContentBackground(.hidden)
                .offset(y: -18)
                .padding(.bottom, -15)
            }
            .padding(.horizontal, 25)
            .frame(width: 800, height: 500, alignment: .leading)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
         
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
        }
    }
}

#Preview {
    SettingsApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false), isHandTrackingDisabled: .constant(false), minPinchDistance: .constant(60.0))
}

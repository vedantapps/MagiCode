//
//  CountdownApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class CountdownState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct CountdownApp: View {
    @State private var dateCountdown = 0
    @State private var isHovering = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    
    var body: some View {
        VStack {
            VStack(alignment: .center, spacing: 20) {
                HStack {
                    Spacer()
                    Image(systemName: "swift")
                        .font(.system(size: 80, weight: .bold, design: .rounded))
                        .padding(.top, 30)
                    Spacer()
                }
                Text("WWDC 2024")
                    .font(.system(size: 60, weight: .bold, design: .rounded))
                    .padding()
                Text("WWDC 2024 will be held this summer. No date quite yet!")
                    .font(.system(size: 22, weight: .medium, design: .rounded))
                Text("Days until June:")
                    .font(.system(size: 30, weight: .medium, design: .rounded))
                Text("\(dateCountdown + 1)")
                    .font(.system(size: 100, weight: .bold, design: .rounded))
                    .padding(.bottom, 30)
            }
            .padding(.horizontal)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
            .onAppear {
                let dubDub24Date = "2024-06-01"
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd"
                let dubDub24Formatted = formatter.date(from: dubDub24Date)
                let currentDate = Date()
                let components = Set<Calendar.Component>([.day])
                let difference = Calendar.current.dateComponents(components, from: currentDate, to: dubDub24Formatted!)
                dateCountdown = difference.day!
            }
          
            Button {
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
                
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
        }
    }
}

#Preview {
    CountdownApp(overlayPoints: .constant([CGPointZero]), distanceCheck: .constant(false))
}

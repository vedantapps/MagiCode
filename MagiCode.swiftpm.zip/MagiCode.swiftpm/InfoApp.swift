//
//  InfoApp.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

class InfoState: ObservableObject {
    @Published var lastExecutionTime: DispatchTime = .now()
    @Published var isHovering = false
    @Published var isShowing = false
}

struct InfoApp: View {
    @State private var isHovering = false
    @Binding var overlayPoints: [CGPoint]
    @Binding var distanceCheck: Bool
    @State private var lastExecutionTime: DispatchTime = .now()
    
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                Text("App Info")
                    .padding(.vertical, 20)
                    .font(.largeTitle)
                    .bold()
                
                MiniAppBody(appName: "Countdown", appDescription: "Count down the days until June 2024.", appLayerName: "CalenderLayer", hasBGColor: false, bgColor: Color.clear)
                Divider()
                MiniAppBody(appName: "MagicDraw", appDescription: "Draw with Apple Pencil or just a pinch of your index finger and thumb.", appLayerName: "DrawLayer", hasBGColor: true, bgColor: Color(red: 0.97, green: 0.82, blue: 0.31))
                Divider()
                MiniAppBody(appName: "Messages", appDescription: "Send and receive messages from the Apple team group chat.", appLayerName: "MessageLayer", hasBGColor: true, bgColor: Color(red: 0.40, green: 0.80, blue: 0.35))
                Divider()
                MiniAppBody(appName: "CodeEdit", appDescription: "Compile the latest update to help the Apple team.", appLayerName: "CodeLayer", hasBGColor: true, bgColor: Color(red: 0.30, green: 0.62, blue: 0.90))
                Divider()
                MiniAppBody(appName: "Photos", appDescription: "Browse photos with just a touch of your index finger and thumb.", appLayerName: "PhotosLayer", hasBGColor: true, bgColor: Color.white)
                Spacer()
            }
            .padding(.horizontal, 25)
            .frame(width: 800, height: 500, alignment: .leading)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .shadow(radius: 10)
            
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 100))
                    .scaleEffect(isHovering ? 1.0 : 0.4)
                    .shadow(radius: isHovering ? 10 : 0)
            }
            .frame(width: 120, height: 120)
            .foregroundColor(.white)
            .hoverOverlay(overlayPoints: overlayPoints, isHovering: $isHovering, distanceCheck: distanceCheck, timeSinceLastExecution: lastExecutionTime, tapAction: {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeApp"), object: self, userInfo: nil)
            })
        }
    }
}

#Preview {
    InfoApp(overlayPoints: .constant([CGPoint.zero]), distanceCheck: .constant(false))
}

struct MiniAppBody: View {
    @State var appName: String
    @State var appDescription: String
    @State var appLayerName: String
    @State var hasBGColor:Bool
    @State var bgColor: Color
    
    var body: some View {
        HStack {
            if hasBGColor {
                ZStack {
                    Circle()
                        .fill(bgColor)
                    Image(appLayerName)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 40, height: 40)
                }
                .frame(width: 60, height: 60)
            }
            if !hasBGColor {
                ZStack {
                    Circle()
                        .fill(.white)
                    Image(appLayerName)
                        .resizable()
                        .scaledToFill()
                        .clipShape(Circle())
                }
                .frame(width: 60, height: 60)
            }
            VStack(alignment: .leading) {
                Text(appName)
                    .bold()
                
                Text(appDescription)
            }
        }
    }
}

//
//  PreInfoView.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/19/24.
//

import SwiftUI

struct PreInfoView: View {
    
    @State private var sectionOne = false
    @State private var sectionTwo = false
    @State private var sectionThree = false
    @State private var sectionFour = false
    @State var cameraStatus: Bool
    @State private var showCameraAlert = false
    @State private var continueOSView = false
    @State private var show4InstructionsAlert = false
    
    var body: some View {
        NavigationStack {
            VStack {
                List {
                    Section {
                        HStack {
                            Spacer()
                            VStack {
                                Image("AppIconSmall")
                                    .resizable()
                                    .frame(width: 150, height: 150, alignment: .center)
                                    .clipShape(RoundedRectangle(cornerRadius: 33.33, style: .continuous))
                                
                                Text("MagiCode Usage Instructions")
                                    .font(.title)
                                    .bold()
                                
                                Text("Read through all 4 instruction sets below for the best possible experience.")
                                    .font(.headline)
                            }
                            Spacer()
                        }
                    }
                    .listRowBackground(Color.clear)
                    .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                    .alert(isPresented: $showCameraAlert) {
                        Alert (title: Text("Camera Access is Disabled"), message: Text("Grant MagiCode camera access in Settings to use the hand tracking features."), primaryButton: .default(Text("Open Settings"), action: { UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)}), secondaryButton: .default(Text("Proceed")))
                    }
                    
                    HStack {
                        Image("iPadAngle")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 280, height: 200, alignment: .center)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .padding(2)
                        
                        Text("For best hand tracking results, ensure the following:\n\n- Your iPad is in landscape\n- Your iPad is steady and at an angle\n- Your iPad is in a well lit environment")
                            .padding()
                            .font(.headline)
                        
                        Spacer()
                        Image(systemName: sectionOne ? "checkmark.circle.fill" : "circle")
                            .foregroundColor(sectionOne ? .green : .gray)
                    }
                    .onTapGesture {
                        withAnimation {
                            sectionOne.toggle()
                        }
                    }
                    HStack {
                        Image("iPadDistance")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 280, height: 200, alignment: .center)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .padding(2)
                        
                        Text("Ensure that only one hand is visible. The sweet spot is around 2 feet - 2.5 feet (24 inches - 30 inches) for hand tracking.\n\nThis might be different for you! Experiment around with placement if hand tracking isn't working well.\n\nAdditionally, you can adjust tracking settings within the 'Settings' app once the main story is complete.")
                            .padding()
                            .font(.headline)
                        
                        Spacer()
                        Image(systemName: sectionTwo ? "checkmark.circle.fill" : "circle")
                            .foregroundColor(sectionTwo ? .green : .gray)
                    }
                    .onTapGesture {
                        withAnimation {
                            sectionTwo.toggle()
                        }
                    }
                    
                    HStack {
                        Image("iPadWholeHand")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 280, height: 200, alignment: .center)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .padding(2)
                        
                        Text("Ensure your full hand is visible for accurate tracking.\n\n- Make sure only one hand is in frame")
                            .padding()
                            .font(.headline)
                        
                        Spacer()
                        Image(systemName: sectionThree ? "checkmark.circle.fill" : "circle")
                            .foregroundColor(sectionThree ? .green : .gray)
                    }
                    .onTapGesture {
                        withAnimation {
                            sectionThree.toggle()
                        }
                    }
                    
                    HStack {
                        Image("iPadSelection")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 280, height: 200, alignment: .center)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .padding(2)
                        
                        Text("Bring your index finger and thumb together (pinch) to make a selection while hovering over what you want to select.\n\n- Ensure your full hand (ALL fingers) remains visible while doing so\n- All buttons can also be tapped on screen manually")
                            .padding()
                            .font(.headline)
                        
                        Spacer()
                        Image(systemName: sectionFour ? "checkmark.circle.fill" : "circle")
                            .foregroundColor(sectionFour ? .green : .gray)
                    }
                    .onTapGesture {
                        withAnimation {
                            sectionFour.toggle()
                        }
                    }
                }
                .frame(maxWidth: 1000)

                Button {
                    if sectionOne && sectionTwo && sectionThree && sectionFour {
                        continueOSView = true
                    } else {
                        show4InstructionsAlert = true
                    }
                } label: {
                    HStack {
                        Text("Continue")
                        Image(systemName: "arrow.right.circle")
                    }
                }
                .font(.largeTitle)
                .padding()
                .buttonStyle(.borderedProminent)
                .alert(isPresented: $show4InstructionsAlert) {
                    Alert (title: Text("Have you read all instructions?"), message: Text("Please ensure you read all 4 instruction sets before continuing for the best possible experience!"), primaryButton: .default(Text("Yes I have"), action: {continueOSView = true}), secondaryButton: .default(Text("Not yet")))
                }
            }
            .navigationTitle("")
            .navigationBarBackButtonHidden(true)
            .scrollContentBackground(.hidden)
            .onAppear {
                if cameraStatus == false {
                    showCameraAlert.toggle()
                }
            }
            .navigationDestination(isPresented: $continueOSView) {
                MainOSView()
                    .navigationTitle("")
                    .navigationBarBackButtonHidden(true)
                    .navigationBarHidden(true)
            }
        }
    }
}

#Preview {
    PreInfoView(cameraStatus: true)
}

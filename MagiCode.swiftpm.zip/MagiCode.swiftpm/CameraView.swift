//
//  CameraView.swift
//  MagiCode
//
//  Created by Vedant Malhotra on 2/10/24.
//

import Foundation
import SwiftUI

struct CameraView: UIViewControllerRepresentable {
    var pointsProcessorHandler: (([CGPoint]) -> Void)?

    func makeUIViewController(context: Context) -> CameraViewController {
        let cameraView = CameraViewController()
        cameraView.pointsProcessorHandler = pointsProcessorHandler
        return cameraView
    }
    func updateUIViewController( _ uiViewController: CameraViewController,  context: Context) {
    }
}
